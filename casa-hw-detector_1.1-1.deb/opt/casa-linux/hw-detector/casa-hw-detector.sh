#!/bin/bash
# casa-hw-detector.sh – Script de detecção de hardware e instalação de drivers
# Adaptado para Casa Linux (Debian 13 hybrid)

clear
echo "----------------------------------------"
echo "   🧙 Casa Linux - Detector de Hardware"
echo "   Versão 1 - por Casa Linux"
echo "----------------------------------------"
echo ""

if [[ $EUID -ne 0 ]]; then
   echo "❌ Este script precisa ser executado como root."
   echo "Use: sudo $0"
   exit 1
fi

echo "🔄 Atualizando lista de pacotes..."
apt update -y

echo ""
echo "🔍 Detectando placa de vídeo..."
GPU_INFO=$(lspci | grep -E "VGA|3D")
echo "📦 Placa de vídeo detectada: $GPU_INFO"

if echo "$GPU_INFO" | grep -iq "NVIDIA"; then
    echo "➡ Instalando driver NVIDIA..."
    apt install -y nvidia-detect
    if nvidia-detect | grep -q "nvidia-driver"; then
        apt install -y nvidia-driver
        echo "✅ Driver NVIDIA instalado."
    else
        echo "⚠️ Driver proprietário não recomendado. Usando driver nouveau."
    fi
elif echo "$GPU_INFO" | grep -iq "AMD"; then
    echo "➡ Instalando drivers AMD..."
    apt install -y firmware-amd-graphics mesa-vulkan-drivers
    echo "✅ Driver AMD instalado."
elif echo "$GPU_INFO" | grep -iq "Intel"; then
    echo "➡ Instalando drivers Intel..."
    apt install -y xserver-xorg-video-intel firmware-intel-graphics mesa-vulkan-drivers
    echo "✅ Driver Intel instalado."
else
    echo "⚠️ Placa de vídeo não reconhecida."
fi

echo ""
echo "🔍 Detectando adaptadores de rede Wi-Fi..."
WIFI_INFO=$(lspci | grep -i "Network")
echo "📶 Adaptador Wi-Fi: $WIFI_INFO"
apt install -y firmware-iwlwifi firmware-atheros firmware-realtek wireless-tools wpasupplicant

echo ""
echo "🔍 Verificando interfaces de rede cabeada..."
ETH_IFACE=$(ip -o link show | awk -F': ' '{print $2}' | grep -E "^en|^eth" | head -n 1)
if [[ -n "$ETH_IFACE" ]]; then
    echo "✅ Interface Ethernet detectada: $ETH_IFACE"
else
    echo "⚠️ Nenhuma interface Ethernet encontrada."
fi

echo ""
echo "✅ Detecção e instalação de drivers finalizada!"
read -p "🔁 Deseja reiniciar agora? [s/N] " REBOOT
if [[ "$REBOOT" =~ ^[Ss]$ ]]; then
    reboot
else
    echo "🧙 Saindo do Detector de Hardware do Casa Linux..."
fi

